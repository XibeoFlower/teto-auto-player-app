## v1.6.1 - 2D/3D roll switch, rainbow notes, brighter 3D, Discord in the sidebar
- *2D / 3D piano roll:* a new "3D roll" toggle (piano / drums / guitar pages and Settings > Piano roll).
  Off (default) = the flat 2D roll: notes fall straight down in plain columns. On = the 3D roll with
  the perspective floor, like the tetoMIDI Lua script. Saved as `roll.mode3d` (default off).
- *Rainbow note colors:* "Note color" in Settings gains a **Rainbow** choice - every pitch class gets
  its own hue (Synthesia style), black keys slightly darker. The key glow now follows the same color.
- *Brighter 3D notes:* all note palettes were lightened, distance fade is much softer and velocity
  shading starts brighter, so falling notes (3D especially) are easier to read.
- *Sidebar:* the entry with the Discord logo is now called **Discord** (it opens the Discord server);
  the separate "Website" entry was removed.
- Version bumped to 1.6.1 (sidebar / settings label stays v1.6).

## v1.6.0 - The old UI is gone: 100% TetoTranscriber interface
- *Old UI removed:* the entire Tkinter interface (the old `tetomidi/ui`) was deleted. tetoMIDI now runs
  on the TetoTranscriber UI engine only: the same frameless liquid-glass main window (rounded 30px
  corners, dark acrylic #0b0b0d, top sheen + diagonal rim light), the same sliding sidebar overlay, the
  same hand-painted glass buttons / toggles / sliders / badges, the same QSS theme (Segoe UI, white on
  black, rounded pills) and the same intro logo animation when the app opens.
- *Everything survives the swap:* Piano / Drums / Guitar pages with the falling-note piano roll, the
  All / Left / Right hand pills and option chips (v1.5.1), MIDI Hub, Settings (hotkeys, speed, fake
  keyboard sound, roll style, background image, opacity, topmost), preview sound, the MIDI Player
  (playlist) window and the Lua-style mini player - all rebuilt as glass widgets in `tetomidi/qtui`,
  ported straight from tetoTranscriber's design.
- *MIDI Player window, glass edition:* playlist with Piano / Drums / Guitar pills, Add files / folder /
  Remove / Clear, PREV / PLAY / STOP / NEXT glass pills, Repeat / Shuffle / speed / Preview controls.
- The title bar has the menu button (opens the sidebar), the app title + current page subtitle with the
  version, Discord / Settings / Mini player / Minimize / Close glass buttons - exactly like the
  Transcriber. The window is dragged from any empty spot, like the Transcriber.
- Requires PySide6 (added to requirements.txt). Version bumped to 1.6.0 (sidebar / settings label v1.6).

## v1.5.1 - Hand mode (all / left / right) + Lua-style mini player buttons
- *Hand mode:* the piano can play everything ("All"), only the left hand (notes below C4) or only the
  right hand (notes from C4 up) - the same split the tetoMIDI Roblox script uses (split note = 60).
  The filter is applied live while playing (note-offs still pass, so nothing sticks) and works for both
  the macro and the preview sound. New "All / Left / Right" pills on the piano page; the choice is saved
  as `piano.hand`.
- *Mini player buttons (like the Lua script):* the mini player gains two more rows straight from the
  Roblox script's mini player - row 4 shows the All / Left / Right hand pills (piano only) and row 5
  shows the instrument's option chips (piano: Preview, 88 key, Sustain, Velocity, Lengths, Loop;
  drums / guitar: Lengths, Loop), highlighted blue when on. The rows rebuild when the mini player
  drives another instrument.
- Version bumped to 1.5.1 (hub user agent; the sidebar / settings label stays v1.5 by design).

## v1.5.0 - TetoTranscriber look, drums & guitar return, Lua-style mini player
- *Transcriber glass UI:* the whole interface now uses the TetoTranscriber design language - near-black
  acrylic surfaces (#0b0b0d), a lighter glass sidebar, buttons painted as thick liquid glass (bright
  diagonal rim, top specular, light gathering along the bottom edge) and the Transcriber blue accent.
- *Drums and Guitar are back:* full player pages again (v1.4.0 removed them), with the same nanoMIDI
  layouts as app v1.3 / the Roblox script: drums = the 21-hit map (b n c v s d f g h x m z e r w o u i a),
  guitar = the piano layout (61 keys + CTRL layer, notes outside 21-108 fold back in by octaves).
  The rolls show drum pads (Kick / Snare / Hi-hat / Open / Tom hi / Tom lo / Crash / Ride / Bell) and six
  guitar strings (E A D G B e). The MIDI player window can drive every instrument again.
- *Mini player (Lua style):* a small always-on-top glass bar like the tetoMIDI Roblox script - icon +
  song name + instrument line + "full" button, elapsed time | thin seek track with a white fill | total
  time, and centred stop / play-pause glass buttons. Opened with the "Mini player" button on every
  instrument page; the main window hides while it is on screen and comes back with "full".
- Version bumped to 1.5.0 everywhere (app, installer, PKGBUILD).

# Changes vs nanoMIDIPlayer-main

**Rewritten / new (package `tetomidi/`, replaces the old app code):** UI (`ui/*`, Pillow-drawn widgets), `engine/transport.py`
(single clock shared by player and piano roll), `engine/dispatchers.py` (piano/drums macros ported with identical semantics,
new guitar), `rollmodel.py`, `midi_data.py` (friendly errors), `keysim.py`, `hotkeys.py`, `config.py`, `defaults*.py`,
`mappings.py`, `paths.py`, `main.py`.
**Added:** `assets/` (icons, fonts, app icon), `scripts/build.py`, `scripts/package_linux.py`, `packaging/windows/installer.nsi`,
`.github/workflows/build-desktop.yml`, `tests/` (60 tests), `README.md`, `NOTICE.md`, `CHANGES.md`, `.gitignore`,
`requirements*.txt`.
**Kept:** `LICENSE` (GPL-3.0).
**Deleted / not carried over:** customtkinter UI and themes, MIDI→QWERTY, MIDI Hub, MIDI-output mode, macOS support,
update checker, telemetry, `bootstrapper.exe`, dependencies customtkinter / keyboard / python-rtmidi / requests / emoji /
markdown / tkinterweb / pygments.

**Since v1.2:** intro screen, animated sidebar, liquid-glass buttons and switches (animated), smaller piano/drum/guitar roll,
"Note lengths" option (off = every note short and equal, in the roll and in the key presses), window opacity setting,
mini player (`ui/mini_player.py`).
**Mini player (update):** round transport buttons (previous, stop, big play / pause, next; previous and next use the
MIDI player list), a collapsible **CONSOLE** that shows the key presses of the shown instrument (Piano / Drum / Guitar,
each with its own history, Clear button, `press: p+shift` style lines). `engine`/`keysim`: key events are labelled with
their source (`ScopedKeys`, `KeySim.add_listener`), `console.py` holds the history. The mini player's setting is
`mini.console`. The MIDI player window has a **Mini player** button. The **Open** button (was "Select file") uses a folder
icon. Icons are drawn as vector shapes in `ui/gfx.py` (`control_icon`, `round_button_image`).
**Roll background picture:** SETTING → Piano roll → *Background image* (JPG, PNG or GIF; a GIF uses its first frame).
The picture is copied to `backgrounds/roll_background.<ext>` in the config folder and shown behind the falling notes of
the Piano, Drum and Guitar rolls. *Background darkness* (0-90%) darkens it. Config: `roll.background`, `roll.backgroundDim`.
Keyboards and drum/guitar pads stay opaque. Code: `gfx.background_image`, `RollView._background`.
**MIDI Player window:** `ui/midi_player_window.py` (playlist, prev/next, seek, repeat, shuffle, speed, instrument choice),
`engine/playlist.py` (play order logic), "MIDI player" button on the instrument pages, `player.*` settings.

**v1.3:**
- *Lighter UI, same look:* converted Tk images are cached (`gfx.photo_cached`, used by every widget in `kit.py`), the roll
  skips frames while the position does not change (paused / stopped), and the main loop slows down to 50 ms while no
  window is visible.
- *Platform code in one place:* `tetomidi/platform_tweaks.py` (DPI + 1 ms timer + taskbar identity on Windows, frame removal
  on Windows / X11, session detection). Tk class name is now `TetoMIDI` (`StartupWMClass` in the Linux `.desktop` file).
  Arch Linux: `packaging/arch/PKGBUILD`.
- *Mini player:* no title bar any more (drag by any empty area, **×** goes back to the main window). Windows: borderless
  window with a taskbar button; Linux: `_MOTIF_WM_HINTS`, so always-on-top keeps working. If the frame cannot be removed,
  the normal title bar stays. The window has rounded corners (`platform_tweaks.round_corners`: Windows 11 DWM, older
  Windows region, X11 Shape extension).
- *Console scrollbar:* dark, slim, self-drawn (`kit.DarkScrollbar`) instead of the white Windows scrollbar.
- *Removed:* the **MIDI player** button of the instrument pages (the window code is still in `ui/midi_player_window.py`).
- *Piano roll:* text on top of the roll (`Piano roll · song name`, `Drum pads · ...`, `Guitar strings · ...`).
- *Intro:* all fade steps are rendered before the clock starts, elements glide up while fading in, smoother easing,
  frame pacing that does not drift.
- *Key letters:* the piano roll prints the mapped computer key on all 61 / 88 keys (`RollView._piano_key_labels`, config
  `roll.keyLabels`, Settings toggle *Key letters (piano)*); CTRL-layer keys are blue.
- *Build:* `scripts/codespace_build_linux.sh` and `scripts/codespace_build_windows.sh` (Wine + NSIS) for GitHub Codespaces.

## v1.4.0 fixes
- `tetomidi/main.py`: a stray literal `\n` made the file a syntax error, so PyInstaller dropped the module and the built app failed with
  `No module named 'tetomidi.main'`. Fixed; `--show-keymaps` is now implemented.
- `scripts/build.py`: fails early on syntax errors and always bundles every `tetomidi` submodule.
- App icon: removed all self-made icon variants (`logo.png`, the old `app.svg`/`logo.svg`); the whole app now uses ONE icon
  (`assets/icons/app.png`, exported as `app.ico` and `app-256.png`): square, no rounded corners.
- Installer/UI icons kept: installer + uninstaller icon, Start-menu/desktop shortcut icons, and the button icons (gear, piano, drum, guitar, hub, reset, discord, globe) with their SVG sources.

## v1.4.0 changes
- Removed the Drum and Guitar players (UI, engine, config, tests, icons). Only the Piano player remains.
- Piano roll is now 3D: notes lie flat on a perspective floor (with a thickness edge) and slide towards the keyboard.
- App icon is the single rounded-square logo again (desktop / installer / window / sidebar).
- Intro: small rounded logo centered on the desktop; corners are see-through on Windows.
- New **Preview sound** toggle on the MIDI PLAYER page: on = Play sounds the MIDI (no macro), off = macro.
- Preview sound toggle also in the MIDI Player window and in Settings; no more "drum" wording in Settings.
- MIDI PLAYER page: visible "Preview sound: on/off" button next to the play/pause/stop hotkeys (besides the toggle in the left list).
- MIDI PLAYER page: compact hotkey strip (play F2, pause F3, stop F4, faster F5, slower F6) with the Preview sound button under it.
- Time read-out (00:00:00/00:00:00) is now drawn as a glass pill like the other buttons.
- Smoother animation: buttons ease their hover and cross-fade colours (e.g. Preview sound on/off); switches glide with ease-in-out and finer steps.
- Faster intro: the logo shows immediately (before the window is built), stays at least 0.35 s and fades out in 0.16 s.
- Tests: removed `test_mini_player_controls_the_active_page_and_returns_to_main` (the app has no mini player any more, so it always failed and stopped the Linux/Windows builds). Build scripts are executable; CODESPACES.md uses `bash scripts/...`.
