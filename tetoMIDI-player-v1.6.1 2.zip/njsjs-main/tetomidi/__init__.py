"""tetoMIDI - MIDI macro player (piano) with a falling-note piano roll.

Derived from nanoMIDIPlayer by NotHammer043 (GPL-3.0).
"""

APP_NAME = "tetoMIDI"
__version__ = "1.6.1"
VERSION_LABEL = "v1.6"   # label only shows major.minor (see tests/test_platform.py)

DISCORD_URL = "https://discord.gg/peaqm6uqgB"
WEBSITE_URL = "https://tetomidi-pianits.vercel.app/"

# MIDI Hub API (see hub_server/README.md). Put the address of the running server here, or set it with the
# environment variable TETOMIDI_HUB_URL, or with "hub.apiUrl" in config.json.
HUB_API_URL = "https://tetomidi.pythonanywhere.com"
