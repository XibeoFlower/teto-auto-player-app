# Build tetoMIDI in GitHub Codespaces

1. Push this repository to GitHub.
2. On GitHub, choose **Code → Codespaces → Create codespace on main**.
3. The `.devcontainer` setup installs Tk, PortAudio and Python requirements.
4. In the Codespaces terminal:

```bash
python -m unittest discover -s tests -t .
python -m tetomidi --debug
```

To build the Linux AppImage and .deb in the Codespace (one command, ~5-10 minutes):

```bash
bash scripts/codespace_build_linux.sh
```

To build only the Linux app folder:

```bash
python scripts/build.py onedir
```

Build artifacts are written to `dist/`. For Windows/macOS installers, use the GitHub Actions workflow in `.github/workflows/build-desktop.yml` (Actions runners are required for native packaging).
