#!/usr/bin/env bash
set -euo pipefail
sudo apt-get update
sudo apt-get install -y python3-tk python3-venv python3-pip libportaudio2 xvfb
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if [ -f requirements-build.txt ]; then python -m pip install -r requirements-build.txt; fi
